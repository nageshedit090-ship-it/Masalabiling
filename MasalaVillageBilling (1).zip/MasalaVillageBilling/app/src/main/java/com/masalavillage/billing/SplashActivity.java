package com.masalavillage.billing;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

public class SplashActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_splash);
        View logo = findViewById(R.id.logo), title = findViewById(R.id.title), tag = findViewById(R.id.tag), bar = findViewById(R.id.bar);
        logo.setScaleX(0.3f); logo.setScaleY(0.3f);
        title.setTranslationY(40f); tag.setTranslationY(30f);
        bar.setPivotX(0f); bar.setScaleX(0f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).setInterpolator(new OvershootInterpolator()).start();
        title.animate().alpha(1f).translationY(0f).setStartDelay(450).setDuration(550).start();
        tag.animate().alpha(1f).translationY(0f).setStartDelay(750).setDuration(550).start();
        bar.animate().scaleX(1f).setDuration(1500).setInterpolator(new AccelerateDecelerateInterpolator()).start();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, 1900);
    }
}
