MASALA VILLAGE BILLING - Android project
1. Install Android Studio. File > Open > select this folder. Wait for Gradle sync.
2. Test: Run (green triangle) with phone USB debugging on, or Build > Build APK(s) for a debug APK.
3. Release: Build > Generate Signed App Bundle / APK > APK. Create a keystore (keep it safe), choose "release".
The app UI lives in app/src/main/assets/index.html - edit menu/prices there.
