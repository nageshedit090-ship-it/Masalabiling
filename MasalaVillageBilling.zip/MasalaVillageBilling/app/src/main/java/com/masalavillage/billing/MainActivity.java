package com.masalavillage.billing;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.View;
import android.webkit.*;
import androidx.webkit.WebViewAssetLoader;
import org.json.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private WebView w;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 1);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        w = new WebView(this);
        setContentView(w);
        w.setBackgroundColor(0xFF14100E);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false); s.setSupportZoom(false); s.setTextZoom(100);
        w.addJavascriptInterface(new Bridge(), "BT");
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return loader.shouldInterceptRequest(r.getUrl()); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });
        w.loadUrl("https://" + HOST + "/assets/index.html");
    }

    class Bridge {
        @JavascriptInterface public void bars(final int color, final boolean darkIcons) {
            runOnUiThread(() -> {
                getWindow().setStatusBarColor(color);
                getWindow().setNavigationBarColor(color);
                w.setBackgroundColor(color);
                if (Build.VERSION.SDK_INT >= 26) {
                    View dv = getWindow().getDecorView();
                    int f = dv.getSystemUiVisibility();
                    int m = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    dv.setSystemUiVisibility(darkIcons ? (f | m) : (f & ~m));
                }
            });
        }
        @JavascriptInterface public void print() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                PrintDocumentAdapter a = w.createPrintDocumentAdapter("Bill");
                pm.print("Masala Village Bill", a, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A6).build());
            });
        }
        @JavascriptInterface public String devices() {
            JSONArray a = new JSONArray();
            try {
                BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
                if (ad != null) for (BluetoothDevice d : ad.getBondedDevices()) a.put(new JSONObject().put("n", d.getName()).put("a", d.getAddress()));
            } catch (Exception ignored) {}
            return a.toString();
        }
        @JavascriptInterface public void printBill(final String addr, final String json, final int width) {
            new Thread(() -> {
                String res = "ok";
                try {
                    byte[] data = raster(render(json, width));
                    BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
                    BluetoothSocket sk = ad.getRemoteDevice(addr).createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                    sk.connect();
                    OutputStream o = sk.getOutputStream();
                    o.write(data); o.flush();
                    Thread.sleep(1500 + data.length / 40);
                    sk.close();
                } catch (Exception e) { res = "Printer error: " + e.getMessage(); }
                final String r = res;
                runOnUiThread(() -> w.evaluateJavascript("btDone(" + JSONObject.quote(r) + ")", null));
            }).start();
        }
    }

    // Draws the bill as an image so Marathi (Devanagari) prints correctly on any thermal printer.
    private Bitmap render(String json, int width) throws Exception {
        JSONArray a = new JSONArray(json);
        int pad = 4, y = pad;
        List<Object[]> L = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            if (o.optInt("d") == 1) { L.add(new Object[]{null, y}); y += 12; continue; }
            if (o.has("qm")) { JSONArray q = o.getJSONArray("qm"); int qn = q.length(); int ms = Math.max(2, ((width - 2 * pad) * 80 / 100) / qn); L.add(new Object[]{"QR", y, q, ms}); y += ms * qn + 16; continue; }
            TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.BLACK); p.setTextSize(o.optInt("px", o.optInt("s", 1) == 2 ? 32 : 22));
            int weight = o.optInt("w", o.optInt("b") == 1 ? 2 : 0);
            String family = "serif".equals(o.optString("f")) ? "serif" : "mono".equals(o.optString("f")) ? "monospace" : weight == 1 ? "sans-serif-medium" : "sans-serif";
            android.graphics.Typeface base = android.graphics.Typeface.create(family, weight == 2 ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            p.setTypeface(base);
            p.setFakeBoldText(weight == 2 || o.optInt("b") == 1);
            String l = o.optString("l"), r = o.optString("r");
            int rw = r.isEmpty() ? 0 : (int) p.measureText(r) + 10;
            Layout.Alignment al = "c".equals(o.optString("a")) ? Layout.Alignment.ALIGN_CENTER : "r".equals(o.optString("a")) ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL;
            StaticLayout sl = StaticLayout.Builder.obtain(l, 0, l.length(), p, width - 2 * pad - rw).setAlignment(al).build();
            L.add(new Object[]{sl, y, r, p});
            y += sl.getHeight() + Math.max(0, o.optInt("g", 4));
        }
        Bitmap bm = Bitmap.createBitmap(width, y + 40, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm); c.drawColor(Color.WHITE);
        Paint line = new Paint(); line.setColor(Color.BLACK); line.setStrokeWidth(2);
        for (Object[] it : L) {
            int yy = (Integer) it[1];
            if ("QR".equals(it[0])) { JSONArray q = (JSONArray) it[2]; int ms = (Integer) it[3], qn = q.length(), x0 = (width - ms * qn) / 2; Paint qp = new Paint(); qp.setColor(Color.BLACK); for (int rr = 0; rr < qn; rr++) { String row = q.optString(rr); for (int cc = 0; cc < qn; cc++) if (row.charAt(cc) == '1') c.drawRect(x0 + cc * ms, yy + 8 + rr * ms, x0 + (cc + 1) * ms, yy + 8 + (rr + 1) * ms, qp); } continue; }
            if (it[0] == null) { c.drawLine(pad, yy + 6, width - pad, yy + 6, line); continue; }
            c.save(); c.translate(pad, yy); ((StaticLayout) it[0]).draw(c); c.restore();
            String r = (String) it[2]; TextPaint p = (TextPaint) it[3];
            if (!r.isEmpty()) c.drawText(r, width - pad - p.measureText(r), yy - p.ascent(), p);
        }
        return bm;
    }

    private byte[] raster(Bitmap b) throws IOException {
        int w = b.getWidth(), h = b.getHeight(), bw = w / 8;
        int[] px = new int[w * h]; b.getPixels(px, 0, w, 0, 0, w, h);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(new byte[]{0x1B, 0x40});
        for (int y0 = 0; y0 < h; y0 += 128) {
            int hh = Math.min(128, h - y0);
            o.write(new byte[]{0x1D, 0x76, 0x30, 0, (byte) (bw & 255), (byte) (bw >> 8), (byte) (hh & 255), (byte) (hh >> 8)});
            for (int y = y0; y < y0 + hh; y++)
                for (int xb = 0; xb < bw; xb++) {
                    int v = 0;
                    for (int k = 0; k < 8; k++) { int c = px[y * w + xb * 8 + k]; v = (v << 1) | (((Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10) < 140 ? 1 : 0); }
                    o.write(v);
                }
        }
        o.write(new byte[]{0x1B, 0x64, 4, 0x1D, 0x56, 0x42, 0});
        return o.toByteArray();
    }

    @Override public void onBackPressed() {
        w.evaluateJavascript("(window.goBack&&goBack())?1:0", v -> { if (!"1".equals(v)) MainActivity.super.onBackPressed(); });
    }
    @Override protected void onPause() { super.onPause(); w.onPause(); }
    @Override protected void onResume() { super.onResume(); w.onResume(); }
    @Override protected void onDestroy() { w.destroy(); super.onDestroy(); }
}
