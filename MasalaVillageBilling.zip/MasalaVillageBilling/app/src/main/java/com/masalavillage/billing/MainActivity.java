package com.masalavillage.billing;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private WebView w;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        w = new WebView(this);
        setContentView(w);
        w.setBackgroundColor(0xFFFFF8EC);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // keeps bill history (localStorage)
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        w.addJavascriptInterface(new Object() {
            @JavascriptInterface public void print() { runOnUiThread(MainActivity.this::doPrint); }
        }, "AndroidPrint");
        w.setWebChromeClient(new WebChromeClient());
        w.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}  // WhatsApp etc.
                return true;
            }
        });
        w.loadUrl("https://" + HOST + "/assets/index.html");
    }

    private void doPrint() {
        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
        PrintDocumentAdapter a = w.createPrintDocumentAdapter("Masala_Village_Bill");
        pm.print("Masala Village Bill", a,
                new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A6).build());
    }

    @Override public void onBackPressed() {
        w.evaluateJavascript("(function(){var b=document.getElementById('bill');if(b&&b.classList.contains('open')){b.classList.remove('open');return 1}return 0})()",
                v -> { if (!"1".equals(v)) MainActivity.super.onBackPressed(); });
    }
    @Override protected void onPause() { super.onPause(); w.onPause(); }
    @Override protected void onResume() { super.onResume(); w.onResume(); }
    @Override protected void onDestroy() { w.destroy(); super.onDestroy(); }
}
